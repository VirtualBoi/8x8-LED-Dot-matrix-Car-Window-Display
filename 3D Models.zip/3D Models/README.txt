The following models (STL) are printable with the following settings:

---------------------------------------------------------------------
The following models require support material: 

	8x8 LED Matrix Housing V2
	8x8 LED Matrix suction cup holder with clip

---------------------------------------------------------------------
The following models DO NOT require support material: 

	8x8 LED Matrix Housing V2 (no slot for suction cup holder)
	8x8 LED Matrix suction cup holder
	Cover